#include "solution.h"

extern const double U_inf;
extern const double rho;
extern const double vi;
extern const double L; 
extern const double epsilon;
extern std::vector<double> coeffs;
extern const double dyn_vi;
extern const double Q;

void solution::residualDerivs()
{
    double c1 = (2/pi - 0.5)*U_inf/vi;
    double locDer;
    for (int i=1; i<nodes; i++)
    {
	locDer = (delta[i]-delta[i-1])/(x[i]-x[i-1]);
	// Calculate partial derivatives of R wrt U (delta) -- Central Differences
	 //+ delta[i]/ ( x[i]-x[i-1] ) 
	locDer = ddx[i];
        pRU(i,i) = c1 * ( locDer + delta[i]/ ( x[i]-x[i-1] ) ) + calcV(x[i]) / vi; // Residuals wrt state vars
        pRU(i,i-1) = c1 * (-delta[i]/ ( x[i]-x[i-1] )); // Residuals wrt state vars

        //pRU(i,i+1) = c1 * ( delta[i]/ ( x[i+1]-x[i-1] ));

	// Calculate partial derivatives of R wrt b
        pRb(i,0) = delta[i]/vi * (pow(x[i],3) - pow(L,3)/4); // Residuals wrt design var 1
        pRb(i,1) = delta[i]/vi * (pow(x[i],2) - pow(L,2)/3); // Residuals wrt design var 2
        pRb(i,2) = delta[i]/vi * (x[i] - L/2); // Residuals wrt design var 3
    }
	// First node is independent of des variables
    pRU(0,0) = 1;
    pRb.row(0) << 0,0,0;

	// Backward differences for last node
    locDer = (delta[nodes]-delta[nodes-1])/(x[nodes]-x[nodes-1]);
    //+ delta[nodes]/(x[nodes] - x[nodes-1]) 
    locDer = ddx[nodes];
    pRU(nodes,nodes) = c1 * ( locDer + delta[nodes]/(x[nodes] - x[nodes-1]) ) + calcV(x[nodes]) / vi; // Residuals wrt state vars
    pRU(nodes,nodes-1) = c1 * (-delta[nodes]/(x[nodes] - x[nodes-1])); // Residuals wrt state vars

    //for (int j = 0; j < nodes; j++)
//	    pRU(nodes,j) = c1;

    pRb(nodes,0) = delta[nodes]/vi * (pow(x[nodes],3) - pow(L,3)/4); // Residuals wrt design var 1
    pRb(nodes,1) = delta[nodes]/vi * (pow(x[nodes],2) - pow(L,2)/3); // Residuals wrt design var 2
    pRb(nodes,2) = delta[nodes]/vi * (x[nodes] - L/2); // Residuals wrt design var 3
}


void solution::objDerivs(){
    
    // Objective function wrt state vars
    // First and last rows have a different formula -- They contribute 1 term to the trapezoid integration
    double fricConst = U_inf*pi*dyn_vi;
    pFU(0,0) = - 0.25 * fricConst * (x[1]-x[0]) /( pow(delta[0],2) );
    pFU(nodes,0) = - 0.25 * fricConst * (x[nodes]-x[nodes-1]) / ( pow(delta[nodes],2) );

    // Calculate derivatives for intermediate nodes -- 2 terms in trapezoid integration (left and right trap)
    for (int i=1; i<nodes; i++) 
    {
       pFU(i,0) =  - fricConst * 0.25 * ( (x[i+1]-x[i])/ ( pow(delta[i],2) ) + (x[i]-x[i-1])/ ( pow(delta[i],2) )); 
    } 
    
}

void solution::calcAdjoint()
{

    std::cout << "Solving discrete adjoint equation... \n";

    Eigen::SparseQR<Eigen::SparseMatrix<double>, Eigen::COLAMDOrdering<int> > matSolver;

     //
    Eigen::SparseMatrix<double> transposed = pRU.transpose().sparseView();
    transposed.makeCompressed();
    matSolver.analyzePattern(transposed);
    matSolver.factorize(transposed);

    adjField = matSolver.solve(pFU);
}

// Main method call to calculate DA Derivatives
void solution::DASens()
{
	// Solve delta field
    solveRungeKutta4();
	// Calculate derivative matrices
    residualDerivs();
    objDerivs();
	// Calculate adjoint field
    calcAdjoint();
	// Derive sensitivity derivatives
    dFb = - adjField.transpose()*pRb;

    std::cout << std::endl << "Discrete Adjoint derivatives: \n";
    std::cout << dFb << "\n" << std::endl;
}
