#include "solution.h"

// Globals declaration
extern const double U_inf;
extern const double rho;
extern const double vi;
extern const double L; 
extern const double epsilon;
extern std::vector<double> coeffs;
extern const double dyn_vi;
extern const double Q;

// Main method to calculate CA derivatives
void solution::CASens() 
{
	// Solve primal field
	solveRungeKutta4();
	// Calculate adjoint field
	calcContAdjoint();

	// Calculate derivatives
	double sum1 = 0; 
	double sum2 = 0; 
	double sum3 = 0; 
	for (int i = 0; i<nodes; i++)
	{
		sum1 += ( contAdjField[2*i] * ( pow(x[i],3) - pow(L,3)/4 ) * delta[i] 
				+ contAdjField[2*(i+1)] * ( pow(x[i+1],3) - pow(L,3)/4 ) * delta[i+1] 
				) * (x[i+1] - x[i]) / 2;

		sum2 += ( contAdjField[2*i] * ( pow(x[i],2) - pow(L,2)/3 ) * delta[i] 
				+ contAdjField[2*(i+1)] * ( pow(x[i+1],2) - pow(L,2)/3 ) * delta[i+1] 
				) * (x[i+1] - x[i]) / 2;

		sum3 += ( contAdjField[2*i] * ( x[i] - L/2 ) * delta[i] 
				+ contAdjField[2*(i+1)] * ( x[i+1] - L/2 ) * delta[i+1] 
				) * (x[i+1] - x[i]) / 2;
	}


	contSens[0] = -sum1/vi;
	contSens[1] = -sum2/vi;
	contSens[2] = -sum3/vi;

}



void solution::calcContAdjoint()
{
	// RK4 for FAE integration
	contAdjField.back() = 0;

	std::vector<double> k(4);
	double dx;

	double alpha = (2/pi - 0.5)*U_inf/vi;
	int j = 0;
	double xnext; 
	double xnow; 
	double delta_here;
	double delta_inter;
	double delta_next;

	// The adjoint field is additionally calculated at the midpoints
	// of the original nodes for improved accuracy

	for (int i = nodes - 1; i>=0; i--)
	{
		// Prosoxi sto prosimo tou dx!!! Ena check metaa
	
		dx = ( x[i] - x[i+1] )/2;
		
		// C = 1 corresponds to intermediate node between x[i] and x[i+1]
		// C = 0 corresponds to node x[i]
		for (double c = 1; c >= 0; c--)
		{
			// save index of new field
			j = 2*i + (int) c;
			// Save x and delta positions for current node (either intermediate (C=1) or same as x[i] (C=0))
			xnext = x[i] - (1+c)*dx; // dx is negative
			xnow = x[i] - c*dx;

			// Delta for the intermediate node is interpolated from grid values
			delta_here = ( c*delta[i+1] + (2-c) * delta[i] ) / 2;
			delta_inter = ( (1 + 2*c) * delta[i+1] + (3 - 2*c) * delta[i]) / 4;
			delta_next = ( (1 + c)*delta[i+1] + (1-c) * delta[i] ) / 2;

			// Calculate Runge Kutta coefficients
			k[0] = dx * ( contAdjField[j+1] * calcV(xnext) / (alpha * vi * delta_next) 
					+ U_inf * pi * dyn_vi / ( 2 * alpha * pow(delta_next,3) ) );

			k[1] = dx * ( ( contAdjField[j+1] + k[0]/2 )* calcV( x[i+1] + dx/2 ) / (alpha * vi * delta_inter ) 
					+ U_inf * pi * dyn_vi / ( 2 * alpha * pow( delta_inter, 3 ) ) );

			k[2] = dx * ( ( contAdjField[j+1] + k[1]/2 )* calcV( x[i+1] + dx/2 ) / (alpha * vi * delta_inter ) 
					+ U_inf * pi * dyn_vi / ( 2 * alpha * pow( delta_inter, 3 ) ) );

			k[3] = dx * ( ( contAdjField[i+1] + k[2] )* calcV( xnow ) / (alpha * vi * delta_here) 
					+ U_inf * pi * dyn_vi / ( 2 * alpha * pow( delta_here ,3) ) );

			contAdjField[j] = contAdjField[j+1] + (k[0] + 2*k[1] + 2*k[2] + k[3]) / 6;  

		}

	}

}

// Unused
double solution::calcAdjF(int ind)
{
	double alpha = (2/pi - 0.5)*U_inf/vi;
	double dpsix =  + contAdjField[ind] * calcV(x[ind]) / (alpha * vi * delta[ind]) 
		- U_inf * pi * dyn_vi / ( 2 * alpha * pow(delta[ind],3) );
	return dpsix;
}
