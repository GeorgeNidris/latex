#include "solution.h"

extern const double U_inf;
extern const double rho;
extern const double vi;
extern const double L; 
extern const double epsilon;
extern std::vector<double> coeffs;
extern const double dyn_vi;
extern const double Q;



// Read design variables from file
void readParams(std::string filename, std::vector<double>& target)
{
    std::ifstream inp(filename);
    std::string line;
    target.resize(4);
    int i = 0;

    // Read point lines
    while(std::getline(inp, line)) {
        target[i] = std::stod(line);
        i++;
    }

    calcD();
    // Close input file
    inp.close();

}

// Calculate dependent (4th) design variable
void calcD(){

    coeffs[3] = (Q - coeffs[0] * pow(L,4) / 4 - coeffs[1] * pow(L,3) / 3 - coeffs[2] * pow(L,2) / 2)/L;

}


// Calculate Node positions
void solution::discretizeGeom(int cellCount, double rate)
{

    double sz = L/((double)cellCount);
// Refinement towards either end of plate
    for (int i = 0; i <= cellCount; i ++)
    {
        //double ratio = (double) i / (double) cellCount;

	// Use cosine to refine mesh on both ends
        //x[i] = L/2*(1-cos( pi * pow(ratio, rate) ));
        x[i] = sz*( (double) i );
    }

}




void solution::solveRungeKutta4()
{
// Initialize variables
    delta[0] = epsilon;
    shear[0] = U_inf * pi * dyn_vi / (2*delta[0]);
    ddx[0] = calcF(0,delta[0]);
    std::vector<double> k(4);
    double dx;

    for (int i = 0; i<nodes; i++)
    {
	// Define length of current step
        dx = x[i+1] - x[i];
	// Calculate RK4 constants
        k[0] = dx*ddx[i];
        k[1] = dx*calcF(x[i] + dx/2, delta[i] + k[0]/2);
        k[2] = dx*calcF(x[i] + dx/2, delta[i] + k[1]/2);
        k[3] = dx*calcF(x[i]+dx,delta[i]+k[2]);
	// Update delta, gradient and shear stress for next step
        delta[i+1] = delta[i] + (k[0] + 3*k[1] + 3*k[2] + k[3])/6;
        ddx[i+1] = calcF(x[i+1],delta[i+1]); 
        shear[i+1] = 0.5 * U_inf * pi * dyn_vi / (delta[i+1]);
    }


}

double solution::calcF(double xval, double yval)
{
    double v = calcV(xval);
    double f = (pi*vi/(2*yval) - v)  / (U_inf * (2/pi - 0.5));
    return f;
}

double solution::calcV(double xval)
{
    double v = coeffs[0]*pow(xval,3) + coeffs[1]*pow(xval,2) + coeffs[2]*xval + coeffs[3];
    return v;
}

double solution::getFriction()
{
    double n = (double) x.size();
    double fr = 0;
    //double fsum = 0;
    // Trapezoid integration
    for (int i = 1; i <= nodes; i++)
    {
        fr += 0.5*(0.5*U_inf*pi*dyn_vi)*(1/delta[i]+1/delta[i-1])*(x[i]-x[i-1]);
    }

    return fr;
}

std::vector<double> solution::FDsens(double step)
{
    // Solve initial field for reference
	//solveRungeKutta4();
    //double F_ref = getFriction();

    std::vector<double> der(3);

	// Μείωση μεταβλητής κατά ε
    coeffs[0] -= step;
	// Επαναυπολογισμός τέταρτης εξαρτημένης μεταβλητής
    calcD();
    // Επίλυση σ.δ.ε
    solveRungeKutta4();
	// Αποθήκευση υπολογισμένης τιμής τριβής
    double F_a1 = getFriction();
	// Αύξηση μεταβλητής κατά ε (σε σχέση με την αρχική)
    coeffs[0] += 2*step;
	// Επαναυπολογισμός τέταρτης εξαρτημένης μεταβλητής
    calcD();
    // Επίλυση σ.δ.ε
    solveRungeKutta4();
	// Αποθήκευση υπολογισμένης τιμής τριβής
    double F_a2 = getFriction();
    // Επαναφορά μεταβλητής στην αρχική τιμή
    coeffs[0] -= step; 
    // Υπολογισμός παραγώγου με πεπερασμένες διαφορές
    der[0] = (F_a2 - F_a1) /(2 * step);

    // Επανάληψη για τις άλλες 2 μεταβλητές
    
	// B2
    coeffs[1] -= step; // Change next variable
    calcD();
    solveRungeKutta4();
    double F_b1 = getFriction();

    coeffs[1] += 2*step; // Change next variable
    calcD();
    solveRungeKutta4();
    double F_b2 = getFriction();


	// B3
    coeffs[1] -= step;
    coeffs[2] -= step;
    calcD();
    solveRungeKutta4();
    double F_c1 = getFriction();

    coeffs[2] += 2*step;
    calcD();
    solveRungeKutta4();
    double F_c2 = getFriction();
    
    coeffs[2] -= step;
    calcD();

	// Calculate derivatives with FD
    der[1] = (F_b2 - F_b1) /(2 * step);
    der[2] = (F_c2 - F_c1) /(2 * step);

    //partFU(step);
    //partRb1(step);
    //partRU50(step);
    return(der);
}


void solution::writeResults(){

    std::ofstream out("iface/delta.dat");
    std::ofstream outDx("iface/deltaX.dat");
    std::ofstream outV("iface/VVeltaX.dat");
    std::ofstream outS("iface/shear.dat");

    for (int i = 0; i<=nodes; i++)
    {
        out << x[i] << " " << delta[i] << "\n";
        outDx << x[i] << " " << ddx[i] << "\n";
        outV << x[i] << " " << calcV(x[i]) << "\n";
        outS << x[i] << " " << shear[i] << "\n";
    }
    
    out.close();
    outDx.close();
    outV.close();
    outS.close();


    std::ofstream adjout("iface/adjField.dat");
    std::ofstream pRbout("iface/prbout.dat");
    std::ofstream pRUout("iface/prUout.dat");
    std::ofstream pFUout("iface/pFUout.dat");
    std::ofstream contAdjout("iface/contAdjField.dat");
    std::ofstream efout("iface/toIntegrate1.dat");
    std::ofstream efout2("iface/toIntegrate2.dat");
    std::ofstream efout3("iface/toIntegrate3.dat");


    for (int i = 0; i<=nodes; i++)
    {
        adjout << x[i] << " " <<  adjField(i,0) << "\n";
        pRbout << x[i] << " " <<  pRb(i,2) << " " << pRb1_FD[i] << "\n";
        pRUout << x[i] << " " <<  pRU(50,i) << " " << pRU50_FD[i] << "\n";
        pFUout << x[i] << " " <<  pFU.row(i) << " " << pFU_FD[i] << "\n";
        efout << x[i] << " " <<  delta[i]*(x[i]-L/2)*contAdjField[i]/vi << std::endl;
        efout2 << x[i] << " " <<  delta[i]*(pow(x[i],2) - pow(L,2)/3)*contAdjField[i]/vi << std::endl;
        efout3 << x[i] << " " <<  delta[i]*(pow(x[i],3) - pow(L,3)/4)*contAdjField[i]/vi << std::endl;
    }

    for (int j = 0; j < (int) contAdjField.size(); j += 2)    
        contAdjout << x[j/2] << " " <<  contAdjField[j] << std::endl;
    
    adjout.close();
    pRbout.close();
    pRUout.close();
    pFUout.close();
    contAdjout.close();
    efout.close();
    efout2.close();
    efout3.close();

}

void solution::partFU(double step)
{
    solveRungeKutta4();
    double f1, f2;
    f1 = getFriction();
    for (int i = 0; i<=nodes; i++)
    {
        delta[i] += step;
        f2 = getFriction();
        delta[i] -= step;
        pFU_FD[i] = (f2-f1)/step;
    }
}

void solution::partRb1(double step)
{
    double R1, R2;
    for (int i = 0; i<=nodes; i++)
    {
        R1 = (2/pi-0.5)*U_inf/vi*delta[i]*ddx[i] + calcV(x[i])*delta[i]/vi - pi/2;
        coeffs[2] += step;
        calcD();
        R2 = (2/pi-0.5)*U_inf/vi*delta[i]*ddx[i] + calcV(x[i])*delta[i]/vi - pi/2;
        coeffs[2] -= step;
        calcD();
        pRb1_FD[i] = (R2-R1)/step;
    }

}


void solution::partRU50(double step)
{
    int pos = 50;
    double R1, R2;
    for (int i = 0; i <=nodes; i++)
    {
        R1 = (2/pi - 0.5)*U_inf/vi*delta[pos]*(delta[pos]-delta[pos-1])/(x[pos]-x[pos-1]) + calcV(x[pos])/vi*delta[pos] - pi/2;
        delta[i] += step;
        R2 = (2/pi - 0.5)*U_inf/vi*delta[pos]*(delta[pos]-delta[pos-1])/(x[pos]-x[pos-1]) + calcV(x[pos])/vi*delta[pos] - pi/2;

        delta[i] -= step;

        pRU50_FD[i] = (R2-R1)/step;
    }

}

// Relic not used

void solution::solveEuler()
{
    delta[0] = epsilon;
    double f;
    shear[0] = U_inf * pi * dyn_vi / (2*delta[0]);

    for (int i = 0; i<nodes; i++)
    {
        f = calcF(x[i], delta[i]);
        delta[i+1] = delta[i] + (x[i+1]-x[i])*f;
        shear[i+1] = U_inf * pi * dyn_vi / (2*delta[i+1]);
    }

    std::ofstream out("iface/euler.dat");

    for (int i = 0; i<nodes+1; i++)
        out << x[i] << " " << delta[i] << "\n";

    out.close();
}
