#include <fstream>
#include <string>
#include <vector>
#include <iostream>
#include "solution.h"
#include <string>

// Globals definition

extern const double U_inf = 10; // m/s
extern const double rho = 1.293; // pyknotita kg*m^-3
extern const double vi = 1.4 * pow(10,-5); // kinimatiki synektikotita m^2*s^-1
extern const double dyn_vi = 1.81*pow(10,-5); // iksodes Pa * s
extern const double L = 1; // length
extern const double epsilon = pow(10,-3); // paxos oriakou stromatos sto x=0
extern const double Q = -0.05; // synoliki paroxi apo trypes
extern const double step = pow(10,-6); // step gia FD
std::vector<double> coeffs(3);

// Function declarations
double err(std::vector<double> inp);
void runDep();
void runOpt(int method, int cells);
void fdDep(int cells);

using namespace std;

int main()
{
    // Read parameters
    readParams("param.dat", coeffs);

    // Read number of cells from console
    std::cout << "Specify number of cells." << std::endl;
    int cells;
    std::string text;
    std::cin >> text;
    std::cin.clear();

    cells = std::stoi(text);

    // Begin with calculating and displaying the derivatives and 
    // friction with current model
    {

        // Construct solution class with number of cells
        solution test(cells);

        // Create node positions
        test.discretizeGeom(cells,1.1);

        // =============================================
        // Calculate derivatives with each method

        // Finite differences
        std::cout << "Finite difference derivatives: \n";
        std::vector<double> ders = test.FDsens(step);

        for (auto& var : ders)
            std::cout << var << " ";
        std::cout << std::endl << std::endl;

        // Discrete adjoint
        test.DASens();

        // Continuous adjoint
        test.CASens();

        std::cout << "Continuous adjoint derivatives: " << std::endl;

        for (auto& var : test.contSens)
            std::cout << var << " ";
        std::cout << std::endl;

        // Display Friction
        std::cout << "Friction: " << test.getFriction() << "N" << std::endl;

        // Get velocity profile on the middle of the plate
        double delta_mid = test.delta[test.nodes/2];// Get Boundary Layer thickness
        int positions = 300;
        std::vector<double> u_y;
        std::vector<double> y;
        u_y.reserve(positions);
        y.reserve(positions);
        double dy = delta_mid/positions;
        std::ofstream outU("iface/x=0.5.dat");

        for (int i = 0; i<=positions; i++)
        {
            y[i] = i*dy;
            u_y[i] = U_inf*sin((pi*y[i])/(2*delta_mid));
            outU << y[i] << " " << u_y[i] << std::endl;
        }
        
        // Write velocity profile 
        outU.close();

        // Write results to files
        test.writeResults();

    }
    
    fdDep(cells);

    bool cont = true;

    // Run cell size dependency check?
    std::cout << "Node dependency check? [y]/[n]";
    std::cin >> text;
    if (text == "y")
        cont = false;

    // Run depend. check
    if (!cont)
        runDep();

    // Run optimization?
    std::cout << "Start Optimization? [y]/[n]";
    std::cin >> text;
    if (text != "y")
        return 0;

    // Read derivative calculation method from console
    std::cout << "Specify derivative calculation method: \n";
    std::cout << "0 -> FD, 1 -> DA, 2 -> CA \n";
    // 0 -> FD, 1 -> DA, 2 -> CA
    std::cin >> text;
    int method = std::stoi(text);
    runOpt(method, cells);

}

// Help function 
// Returns maximum absolute derivative (error) for convergence check
double err(std::vector<double> inp)
{
    inp[0] = abs(inp[0]);
    inp[1] = abs(inp[1]);
    inp[2] = abs(inp[2]);
    return max(inp[0], max(inp[1],inp[2]));
}

void runDep()
{

        int startCells = 100;
        int endCells = 4000;
        int increment = 200;
        std::vector<double> fdDers;
        fdDers.resize(3);

        std::vector<double> DADers;
        DADers.resize(3);

        std::vector<double> CADers;
        CADers.resize(3);

        std::ofstream outCA("iface/CA.dat");
        std::ofstream outDA("iface/DA.dat");
        std::ofstream outFD("iface/FD.dat");
        std::ofstream outFR("iface/F_vs_nodes.dat");

    // Loop for every cell count
        for (int i = startCells; i <= endCells; i += increment)
        {
            // Initialize
            solution instance(i);
            instance.discretizeGeom(i,1.1);
        
            // Calc Finite Difference 
            fdDers = instance.FDsens(step);

            // Calc discrete adjoint
            instance.DASens();
            DADers[0] = instance.dFb(0,0);
            DADers[1] = instance.dFb(0,1);
            DADers[2] = instance.dFb(0,2);

            // Calc continuous adjoint
            instance.CASens();
            CADers = instance.contSens;

            // Write results
            outFD << i << " " << fdDers[0] << " " << fdDers[1] << " " << fdDers[2] << std::endl;
            outDA << i << " " << DADers[0] << " " << DADers[1] << " " << DADers[2] << std::endl;
            outCA << i << " " << CADers[0] << " " << CADers[1] << " " << CADers[2] << std::endl;

            outFR << i << " " << instance.getFriction() << std::endl;

        }

        outCA.close();
        outDA.close();
        outFD.close();
        outFR.close();
 
}

void runOpt(int method, int cells)
{
    // Initialize solution class
    solution opt(cells);

    opt.discretizeGeom(cells,1.1);

    // Initialize optimization parameters
    int maxIter = 1000;
    double n = 50000;
    int i = 0;
    double convThres = pow(10,-10);
    double prevVal = opt.getFriction();
    double newVal = 0;
    int idleCount = 0;
    int idleThres = 30; // Number of iterations allowed with same value


    // Initialize derivative values
    std::vector<double> SDders(3);

    switch(method){
    case 0: // Finite differences
        SDders = opt.FDsens(step);
        break;
    case 1: // Discrete Adjoint
        opt.DASens();
        SDders[0] = opt.dFb(0,0);
        SDders[1] = opt.dFb(0,1);
        SDders[2] = opt.dFb(0,2);
        break;
    case 2: // Continuous adjoint
        opt.CASens();
        SDders = opt.contSens;
    }

    // Convergence output file
    std::string filename = "iface/F_vs_iter" + std::to_string(method) + ".dat";
    std::string filename_der = "iface/dF_vs_iter" + std::to_string(method) + ".dat";
    std::ofstream outIter(filename);
    std::ofstream outDer(filename_der);
    
    double c = 0.8;
    Eigen::Matrix<double, 3,1> nablaF;
    nablaF.setZero();
    
    // Main optimization loop
    while (i <= maxIter && idleCount < idleThres)
    {
        // Write results of current step
        outIter << i << " " << coeffs[0] << " " << coeffs[1] << " " << coeffs[2] << " " << prevVal << std::endl; 
        outDer << i << " " << SDders[0] << " " << SDders[1] << " " << SDders[2] << " " << std::endl; 

        prevVal = opt.getFriction();

        // Update design variables
        coeffs[0] = coeffs[0] - n*SDders[0];
        coeffs[1] = coeffs[1] - n*SDders[1];
        coeffs[2] = coeffs[2] - n*SDders[2];
        calcD();

        nablaF(0) = SDders[0];
        nablaF(1) = SDders[1];
        nablaF(2) = SDders[2];
        // Update derivatives 
        switch(method){
            case 0: // Finite Differences
                SDders = opt.FDsens(step);
                break;
            case 1: // Discrete Adjoint
                opt.DASens();
                SDders[0] = opt.dFb(0,0);
                SDders[1] = opt.dFb(0,1);
                SDders[2] = opt.dFb(0,2);
                break;
            case 2: // Continuous Adjoint
                opt.CASens();
                SDders = opt.contSens;
        }   

        // Update objective value
        newVal = opt.getFriction();

        // Convergence check
        if (abs(newVal - prevVal) < convThres)
        {
            idleCount++;
        }else
            idleCount = 0;

        // Adaptive step
        // Wolfe condition
        double prod = nablaF.transpose()*nablaF;
        if (bool res = newVal <= prevVal + c*n*prod)
        {
            n = 2*n;
        }else {
            n = n/2;
        }

        i++;
    }

    outIter.close();
    outDer.close();

    // Display results
    std::cout << "========================" << std::endl;

    std::cout << "Optimization Ended." << std::endl;

    std::cout << std::endl << "Number of idle iterations: " << idleCount << std::endl;
    std::cout <<  "Number of total iterations: " << i << std::endl << std::endl;

    std::cout << "Final derivatives:" << std::endl;
    opt.CASens();
    for (auto& der : opt.contSens)
        std::cout << der << " ";


    std::cout << std::endl << "Final values of design variables: \n";
    for (auto& var : coeffs)
        std::cout << var << " ";
    std::cout << std::endl;


}

void fdDep(int cells)
{
    solution instance(cells);
    instance.discretizeGeom(cells,1);
    double var_step;
    std::vector<double> sens(3);
    std::ofstream outFD_dep("iface/FD_vs_step.dat");
    
    for (float e = -0.5; e >= -8; e -= 0.5)
    {
        var_step = pow(10,e);
        sens = instance.FDsens(var_step);
        outFD_dep << var_step << " " << sens[0] << " " << sens[1] << " " << sens[2] << std::endl;
    }

    outFD_dep.close();

}

