#pragma once

#include <fstream>
#include <string>
#include <vector>
#include <iostream>
#include <stdlib.h>
#include <math.h>
#include <Eigen/Dense>
#include <Eigen/SparseLU>
#include <Eigen/SparseQR>

#define pi 3.14159265358979323846 

// General function declaration

void readParams(std::string filename, std::vector<double>& target);
void calcD();



// A class oblect is utilized to perform all
// main problem related calculations 

// Class declaration

class solution {

    private:
    // Private intermediate methods

    double calcF(double xval, double yval); // Calculate primal dy/dx
    double calcV(double xval); // Calculate V velocity at position x
    double calcAdjF(int ind); // Obsolete To Delete
    
    public:
    
    // General variables
    int nodes; // Used for indexing (NOT actual nodes count)


    std::vector<double> delta; // Boundary Layer thickness field
    std::vector<double> ddx; // dy/dx field (gradient of boundary layer thickness)
    std::vector<double> x; // Node positions
    std::vector<double> shear; // Shear stress at every node
    std::vector<double> contAdjField; // Continuous adjoint field
    std::vector<double> contSens; // Sensitivity derivatives by continuous adjoint

    // General methods
    void discretizeGeom(int cellCount, double rate); // Calculate node positions
    void solveEuler(); // Obsolete solve Boundary Layer thickness with Euler integration
    void solveRungeKutta4(); // Numerical Solver: Calculate boundary thickness with Runge Kutta 4th order
    double getFriction(); // Calculate Friction (Objective Function)
    void writeResults(); 

    // ====================
    // Finite differences
    std::vector<double> FDsens(double step); // Calculate sensitivity derivatives with Finite Differences
    std::vector<double> pFU_FD;
    std::vector<double> pRb1_FD;
    std::vector<double> pRU50_FD;
    void partFU(double step);
    void partRb1(double step);
    void partRU50(double step);

    // ====================
    // Discrete Adjoint
    
    // Discrete Adjoint Matrices
    Eigen::Matrix<double,Eigen::Dynamic, Eigen::Dynamic> pRU; // Residuals wrt state vars 
    Eigen::Matrix<double,Eigen::Dynamic, Eigen::Dynamic> pRb; // Residuals wrt design vars
    Eigen::Matrix<double,Eigen::Dynamic, Eigen::Dynamic> pFU; // Objective func wrt state vars
    Eigen::Matrix<double,Eigen::Dynamic, Eigen::Dynamic> adjField; // Discrete Adjoint field
    Eigen::Matrix<double,Eigen::Dynamic, Eigen::Dynamic> dFb; // Discrete Adjoint sensitivity derivatives
    
    // Discrete Adjoint methods
    void residualDerivs(); // Calculate residual derivatives
    void objDerivs(); // Calculate objective function derivatives
    void calcAdjoint(); // Calculate discrete adjoint field
    void DASens(); // Calculate discrete adjoint sensitivity derivatives

    // ====================
    // Continuous Adjoint
    void calcContAdjoint();   
    void CASens();   



    // Class constructor
    solution(int cellCount) :
    nodes(cellCount), // nodes var is used for indexing 
                      //(0 index -> index of [nodes] corresponds to final node)
    delta(cellCount+1),
    ddx(cellCount+1),
    x(cellCount+1),
    shear(cellCount+1),
    contAdjField(2*cellCount + 1),
    contSens(3),
    pFU_FD(cellCount+1),
    pRb1_FD(cellCount+1),
    pRU50_FD(cellCount+1)
    {
       pRU.resize(cellCount+1,cellCount+1); 
       pRb.resize(cellCount+1,3); 
       pFU.resize(cellCount+1,1); 
       adjField.resize(cellCount+1,1); 
       dFb.resize(3,1); 
       
       pRU.setZero(); 
       pRb.setZero(); 
       pFU.setZero(); 
       adjField.setZero(); 
    }


    // Class destructor
    
    ~solution(){

    }

};
