import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

# Load data from files with space-separated values
boundary_layer_data = pd.read_csv("delta.dat", sep=' ', header=None, names=['x', 'boundary_layer_thickness'])
velocity_data = pd.read_csv("x=0.5.dat", sep=' ', header=None, names=['y', 'velocity'])

# Convert 'y' column to numeric
velocity_data['y'] = pd.to_numeric(velocity_data['y'], errors='coerce')
velocity_data['velocity'] = pd.to_numeric(velocity_data['velocity'], errors='coerce')

# Extract data
x_values_boundary_layer = boundary_layer_data['x']
thickness_values = boundary_layer_data['boundary_layer_thickness']
y_values_velocity = velocity_data['y']
x_values_velocity = velocity_data['velocity']
velocity_profile_values = velocity_data['velocity']

# Calculate the middle of the plate
length = (x_values_boundary_layer.min() + x_values_boundary_layer.max())
middle_plate = 0.5 * length
scale_factor = 0.25 * length/x_values_velocity.max()
# Overlay velocity profile (scaling x-axis)
x_values_velocity = middle_plate + scale_factor * x_values_velocity  # Centering around the middle
plt.plot(x_values_velocity, y_values_velocity, label='Προφίλ ταχύτητας', linestyle='--', color='red')

plt.xlim(0, length * 1.05)
plt.ylim(0, thickness_values.max() * 1.05)  # Assuming the y-axis should start from 0 to 1

# Plot boundary layer thickness
plt.plot(x_values_boundary_layer, thickness_values, label='Πάχος οριακού στρώματος')
plt.axvline(x=middle_plate, color='black', label='x=L/2', ymin=0, ymax=y_values_velocity.max())
plt.axhline(y=y_values_velocity.max(), color='black', xmin=middle_plate, xmax=0.735 * length)

tick_spacing = 0.1  # Adjust this value based on your preference
plt.xticks(np.arange(0, x_values_boundary_layer.max() + tick_spacing, tick_spacing))

# Customize the plot
plt.title('Πάχος οριακού στρώματος - Προφίλ ταχύτητας στη θέση x = L/2',fontdict={'fontname': 'CMU Serif', 'fontsize': 26})
plt.xlabel('x (m)',fontdict={'fontname': 'CMU Serif', 'fontsize': 20})
plt.ylabel('Πάχος οριακού στρώματος (m)',fontdict={'fontname': 'CMU Serif', 'fontsize': 20})
plt.legend(fontsize=12, loc='upper right')
plt.grid(True)
plt.show()

