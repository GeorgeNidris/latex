import numpy as np
import matplotlib.pyplot as plt

# Define the function to read data from a file
def read_data(file_path):
    data = np.loadtxt(file_path)
    return data[:, 0], data[:, 1]

# Define the function to calculate the area under the curve using the trapezoidal rule
def calculate_area(x, y):
    dx = np.diff(x)
    area = np.sum((y[:-1] + y[1:]) * dx) / 2.0
    return area

# Specify the file paths (change them accordingly)

file_paths = ['toIntegrate1.dat', 'toIntegrate2.dat', 'toIntegrate3.dat']

# Initialize lists to store data, areas, and labels
all_x_values = []
all_y_values = []
all_areas = []
curve_labels = []

# Loop through each file
for file_path in file_paths:
    # Read data from the file
    x, y = read_data(file_path)
    all_x_values.append(x)
    all_y_values.append(y)

    # Calculate the area under the curve
    area = calculate_area(x, y)
    all_areas.append(area)

    # Extract the curve label from the file name
    curve_label = file_path.replace('.txt', '')
    curve_labels.append(curve_label)

# Plot the curves
for x, y, label in zip(all_x_values, all_y_values, curve_labels):
    plt.plot(x, y, label=label)

# Add labels and title
plt.xlabel('X-axis label')
plt.ylabel('Y-axis label')
plt.title('Curves and Areas Under the Curves')

# Add legend
plt.legend()

# Display areas for each curve with double precision
for label, area in zip(curve_labels, all_areas):
    print(f'Area under {label}: {area:.16f}')  # Increased precision to 16 decimal places

# Calculate and print the ratios of the areas
ratio_1_to_2 = all_areas[0] / all_areas[1]
ratio_1_to_3 = all_areas[0] / all_areas[2]
ratio_2_to_3 = all_areas[1] / all_areas[2]

print(f'Ratio of Area1 to Area2: {ratio_1_to_2:.16f}')
print(f'Ratio of Area1 to Area3: {ratio_1_to_3:.16f}')
print(f'Ratio of Area2 to Area3: {ratio_2_to_3:.16f}')

# Show the plot
plt.show()
